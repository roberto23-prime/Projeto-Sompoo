import streamlit as st
import pandas as pd
import numpy as np
import joblib
import os
import warnings
warnings.filterwarnings('ignore')

st.set_page_config(page_title="Sompo Seguros", layout="wide")
st.title("Calculadora de Risco de Roubo de Carga")
st.markdown("### Sompo Seguros - Análise com IA")

@st.cache_resource
def carregar_modelo_real():
    """Carrega seu modelo real"""
    arquivos = {
        'modelo': None, 'encoders': None, 'dados': None
    }
    
    # Detectar arquivos
    for arquivo in os.listdir('.'):
        if arquivo.endswith('.pkl'):
            try:
                obj = joblib.load(arquivo)
                if hasattr(obj, 'predict_proba') and 'RandomForest' in str(type(obj)):
                    arquivos['modelo'] = arquivo
                elif isinstance(obj, dict) and 'Tipo de Carga' in obj:
                    arquivos['encoders'] = arquivo
                elif isinstance(obj, pd.DataFrame):
                    arquivos['dados'] = arquivo
            except:
                continue
    
    if all(arquivos.values()):
        rf_model = joblib.load(arquivos['modelo'])
        label_encoders = joblib.load(arquivos['encoders'])
        data_original = pd.read_pickle(arquivos['dados'])
        return rf_model, label_encoders, data_original
    return None, None, None

# Carregar
rf_model, label_encoders, data_original = carregar_modelo_real()

if rf_model is not None:
    st.success("✅ MODELO REAL CARREGADO!")
    st.info(f"Dataset: {len(data_original)} registros")
    
    # Interface principal
    col1, col2 = st.columns([1, 2])
    
    with col1:
        st.header("Parâmetros")
        
        # Widgets únicos (sem duplicatas)
        tipos_carga = list(label_encoders['Tipo de Carga'].classes_)
        estados = list(label_encoders['Estado'].classes_)
        caminhões = list(label_encoders['Caminhão Roubado'].classes_)
        
        tipo = st.selectbox("Tipo de Carga", tipos_carga)
        peso = st.slider("Peso (kg)", 100, 1500, 500)
        caminhao = st.selectbox("Caminhão", caminhões)
        estado = st.selectbox("Estado", estados[:10])  # Limitar
        
        # Cidades filtradas
        mask = data_original['Estado'] == estado
        cidades = data_original.loc[mask, 'Cidade'].dropna().unique()[:20]
        cidade = st.selectbox("Cidade", cidades)
        
        if st.button("Calcular Risco"):
            try:
                # Cálculo real
                novo_dado = pd.DataFrame({
                    'Tipo de Carga': [label_encoders['Tipo de Carga'].transform([tipo])[0]],
                    'Peso da Carga (kg)': [peso],
                    'Caminhão Roubado': [label_encoders['Caminhão Roubado'].transform([caminhao])[0]],
                    'Ano': [2023],
                    'Estado': [label_encoders['Estado'].transform([estado])[0]],
                    'Cidade': [label_encoders['Cidade'].transform([cidade])[0]],
                    'Estrada': [0],  # Placeholder
                    'Rodovia': [0],  # Placeholder
                    'Latitude': [-23.55],
                    'Longitude': [-46.63]
                })
                
                prob = rf_model.predict_proba(novo_dado)[:, 1][0] * 100
                pred = rf_model.predict(novo_dado)[0]
                
                # Resultados
                col_a, col_b = st.columns(2)
                with col_a:
                    st.metric("Probabilidade", f"{prob:.2f}%")
                with col_b:
                    risco = "ALTO" if prob > 70 else "MÉDIO" if prob > 40 else "BAIXO"
                    st.metric("Risco", risco)
                
                st.success(f"Previsão: {'ROUBO' if pred == 1 else 'SEGURANÇA'} PROVÁVEL")
                
            except Exception as e:
                st.error(f"Erro: {e}")
else:
    st.warning("⚠️ MODO DEMO - Baixe arquivos .pkl do Colab")
    st.info("Seu modelo está carregado, mas precisa de configuração adicional.")
        
        # Demo simples
    tipo = st.selectbox("Demo - Tipo", ['Joias', 'Eletrônicos'])
    if st.button("Teste Demo"):
            prob = 65.0 if tipo == 'Joias' else 35.0
            st.metric("Probabilidade Demo", f"{prob}%")
            st.warning("MÉDIO RISCO" if prob > 40 else "BAIXO RISCO")

st.markdown("---")
st.caption("© Sompo Seguros - Sistema de IA para Risco de Carga")